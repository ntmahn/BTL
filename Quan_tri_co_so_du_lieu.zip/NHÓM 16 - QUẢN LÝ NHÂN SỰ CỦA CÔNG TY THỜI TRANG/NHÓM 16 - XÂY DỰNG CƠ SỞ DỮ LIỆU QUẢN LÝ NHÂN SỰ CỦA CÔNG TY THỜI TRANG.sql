--Tao tablespace
CREATE TABLESPACE TBS01
 DATAFILE 'tbs01.dbf' SIZE 100M
 AUTOEXTEND ON NEXT 2000M MAXSIZE UNLIMITED;
CREATE TABLESPACE TBS02
 DATAFILE 'TBS02.dbf' SIZE 200M
 AUTOEXTEND ON NEXT 4000M MAXSIZE UNLIMITED
 
--Tao bang Bo Phan
create table bophan(
 MaBP char(10) primary key,
 TenBP nvarchar2(30)
);

--Tao bang Chuc Vu
create table chucvu(
 MaCV char(10) primary key,
 TenCV nvarchar2(30)
);

--Tao bang Trinh Do
create table trinhdo(
 MaTD char(10) primary key,
 TenTD nvarchar2(30)
);

--Tao bang Nhan Vien
create table NhanVien (
 MaNV char(10) primary key,
 MaBP char(10),
 MaCV char(10),
 MaTD char(10),
 HoTen nvarchar2(50),
 GioiTinh nvarchar2(10),
 NgaySinh date,
 DienThoai varchar2(15),
 CCCD char(9),
 DiaChi nvarchar2(100),
 foreign key (MaBP) references bophan(MaBP),
 foreign key (MaCV) references chucvu(MaCV),
 foreign key (MaTD) references trinhdo(MaTD)
);

--Tao bang Loai Hop Dong
create table loaihopdong(
 MaLHD char(10) primary key,
 TenLHD nvarchar2(30)
);

--Tao bang Hop Dong
create table hopdong (
 MaHD char(10) primary key,
 MaLHD char(10) ,
 MaNV char(10),
 NgayBatDau DATE,
 NgayKetThuc DATE,
 ThoiHan char(10),
 LanKy INT,
 NgayKy DATE,
 LuongCoBan NUMBER(10, 2),
 NoiDung NVARCHAR2(1000),
 FOREIGN KEY (MaLHD) REFERENCES
loaihopdong(MaLHD),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
);

--Tao bang Bao Hiem
CREATE TABLE baohiem (
 MaBH char(10) PRIMARY KEY,
 MaNV char(10),
 SoBH VARCHAR2(20),
 NgayCap DATE,
 NoiCap NVARCHAR2(255),
 NoiKhamBenh NVARCHAR2(255),
 NoiDangKi NVARCHAR2(255),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
);

--Tao bang Khen Thuong
CREATE TABLE khenthuong (
 MaKT char(10) PRIMARY KEY,
 MaNV char(10),
 QDKT VARCHAR2(20),
 Ngay DATE,
 NoiDung NVARCHAR2(255),
 SoTien NUMBER(10, 2),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
);

--Tao bang Ky luat
CREATE TABLE kyluat (
 MaKL char(10) PRIMARY KEY,
 MaNV char(10),
 SoQDKL VARCHAR2(20),
 Ngay DATE,
 NoiDungKyLuat NVARCHAR2(255),
 SoTien NUMBER(10, 2),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
);

--Tao bang loai ca
CREATE TABLE loaica (
 MaLoaiCa char(10) PRIMARY KEY,
 TenLoaiCa NVARCHAR2(50),
 HeSo NUMBER(5, 2)
);

--Tao bang tang ca
CREATE TABLE tangca (
 MaTC char(10) PRIMARY KEY,
 MaNV char(10),
 MaLoaiCa char(10),
 Ngay DATE,
 SoGio NUMBER(5, 2),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV),
 FOREIGN KEY (MaLoaiCa) REFERENCES
loaica(MaLoaiCa)
);

--Tao bang Loai cong
CREATE TABLE loaicong (
 MaLC char(10) PRIMARY KEY,
 TenLoaiCong NVARCHAR2(50),
 HeSo NUMBER(5, 2)
);

--tao bang Bang cong
CREATE TABLE bangcong (
 MaBC CHAR(10) PRIMARY KEY,
 MaLC CHAR(10),
 MaNV CHAR(10),
 GioVao TIMESTAMP,
 GioRa TIMESTAMP,
 TongSoGio NUMBER(5,2),
 FOREIGN KEY (MaLC) REFERENCES loaicong(MaLC),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

--tao bang Thai san
CREATE TABLE thaisan (
 MaNV char(10) PRIMARY KEY,
 HoTen nvarchar2(50),
 NgayNghiSinh date,
 NgayTroLaiLam date,
 TroCap NUMBER(10, 2),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
);

--Tao bang Phu Cap
CREATE TABLE phucap (
 MaPC char(10) PRIMARY KEY,
 TenPhuCap NVARCHAR2(50),
 SoTien NUMBER(10, 2)
);

--Tao bang Phu cap Nhan vien
CREATE TABLE nv_phu_cap (
 MaNV CHAR(10),
 MaPC CHAR(10),
 TenPhuCap NVARCHAR2(50),
 PRIMARY KEY (MaNV, MaPC),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV),
 FOREIGN KEY (MaPC) REFERENCES phucap(MaPC)
);

--Tao bang Dieu chuyen
CREATE TABLE dieuchuyen (
 SoQDDC CHAR(10) PRIMARY KEY,
 MaNV CHAR(10),
 MaBPCu CHAR(10),
 MaBPMoi CHAR(10),
 LyDo NVARCHAR2(100),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV),
 FOREIGN KEY (MaBPCu) REFERENCES bophan(MaBP),
 FOREIGN KEY (MaBPMoi) REFERENCES bophan(MaBP)
);

--T?o b?ng Th�i vi?c
CREATE TABLE thoiviec (
 SoQDTV CHAR(10) PRIMARY KEY,
 MaNV CHAR(10),
 NgayThoiViec DATE,
 LyDo NVARCHAR2(100),
 FOREIGN KEY (MaNV) REFERENCES nhanvien(MaNV)
); 

-- T?o b?ng T�ng l��ng
CREATE TABLE tangluong (
 SoQDTL CHAR(10) PRIMARY KEY,
 MaNV CHAR(10),
 MaBP CHAR(10),
 MaCV CHAR(10),
 NgayTangLuong DATE,
 NoiDung NVARCHAR2(100),
 SoTien NUMBER(10, 2),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV),
 FOREIGN KEY (MaBP) REFERENCES bophan(MaBP),
 FOREIGN KEY (MaCV) REFERENCES chucvu(MaCV)
);

-- T?o b?ng K? ch?m c�ng
CREATE TABLE kychamcong (
 MaKCC CHAR(10) PRIMARY KEY,
 Thang NUMBER,
 Nam NUMBER,
 NgayTinhCong DATE
);

-- T?o b?ng Chi ti?t k? ch?m c�ng
CREATE TABLE CT_KCC (
 MaKCC CHAR(10),
 MaNV CHAR(10),
 D1 NUMBER(1,0) CHECK (D1 IN (0, 1)),
 D2 NUMBER(1,0) CHECK (D2 IN (0, 1)),
 D3 NUMBER(1,0) CHECK (D3 IN (0, 1)),
 D4 NUMBER(1,0) CHECK (D4 IN (0, 1)),
 D5 NUMBER(1,0) CHECK (D5 IN (0, 1)),
 D6 NUMBER(1,0) CHECK (D6 IN (0, 1)),
 D7 NUMBER(1,0) CHECK (D7 IN (0, 1)),
 D8 NUMBER(1,0) CHECK (D8 IN (0, 1)),
 D9 NUMBER(1,0) CHECK (D9 IN (0, 1)),
 D10 NUMBER(1,0) CHECK (D10 IN (0, 1)),
 D11 NUMBER(1,0) CHECK (D11 IN (0, 1)),
 D12 NUMBER(1,0) CHECK (D12 IN (0, 1)),
 D13 NUMBER(1,0) CHECK (D13 IN (0, 1)),
 D14 NUMBER(1,0) CHECK (D14 IN (0, 1)),
 D15 NUMBER(1,0) CHECK (D15 IN (0, 1)),
 D16 NUMBER(1,0) CHECK (D16 IN (0, 1)),
 D17 NUMBER(1,0) CHECK (D17 IN (0, 1)),
 D18 NUMBER(1,0) CHECK (D18 IN (0, 1)),
 D19 NUMBER(1,0) CHECK (D19 IN (0, 1)),
 D20 NUMBER(1,0) CHECK (D20 IN (0, 1)),
 D21 NUMBER(1,0) CHECK (D21 IN (0, 1)),
 D22 NUMBER(1,0) CHECK (D22 IN (0, 1)),
 D23 NUMBER(1,0) CHECK (D23 IN (0, 1)),
 D24 NUMBER(1,0) CHECK (D24 IN (0, 1)),
 D25 NUMBER(1,0) CHECK (D25 IN (0, 1)),
 D26 NUMBER(1,0) CHECK (D26 IN (0, 1)),
 D27 NUMBER(1,0) CHECK (D27 IN (0, 1)),
 D28 NUMBER(1,0) CHECK (D28 IN (0, 1)),
 D29 NUMBER(1,0) CHECK (D29 IN (0, 1)),
 D30 NUMBER(1,0) CHECK (D30 IN (0, 1)),
 D31 NUMBER(1,0) CHECK (D31 IN (0, 1)),
 TongNgayCong NUMBER,
 PRIMARY KEY (MaKCC, MaNV),
 FOREIGN KEY (MaKCC) REFERENCES kychamcong(MaKCC),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
-- T?o b?ng Chi ti?t b?ng c�ng
CREATE TABLE ChiTietBangCong (
 MaBC CHAR(10),
 MaKCC CHAR(10),
 MaNV CHAR(10),
 Ngay DATE,
 GioVao TIMESTAMP,
 GioRa TIMESTAMP,
 NgayPhep NUMBER(5,2),
 CongNgayLe NUMBER(5,2),
 CongChuNhat NUMBER(5,2),
 PRIMARY KEY (MaBC, MaKCC, MaNV),
 FOREIGN KEY (MaBC) REFERENCES bangcong(MaBC),
 FOREIGN KEY (MaKCC) REFERENCES kychamcong(MaKCC),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
-- T?o b?ng L��ng
CREATE TABLE Luong (
 MaBL CHAR(10) PRIMARY KEY,
 MaKCC CHAR(10),
 MaNV CHAR(10),
 HoTen NVARCHAR2(50),
 NgayCongTrongThang NUMBER(5,2),
 NgayPhep NUMBER(5,2),
 KhongPhep NUMBER(5,2),
 NgayLe NUMBER(5,2),
 NgayChuNhat NUMBER(5,2),
 FOREIGN KEY (MaKCC) REFERENCES kychamcong(MaKCC),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
-- T?o b?ng Th? vi?c
CREATE TABLE ThuViec (
 MaNVTV CHAR(10) PRIMARY KEY,
 MaNV CHAR(10),
 HoTen NVARCHAR2(50),
 BoPhanThuViec CHAR(10),
 FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV),
 FOREIGN KEY (BoPhanThuViec) REFERENCES
bophan(MaBP)
);

--Nh?p d? li?u v�o cho t?t c? c�c b?ng
-- B?ng B? ph?n
insert into bophan values('LT', 'Le tan');
insert into bophan values('KT', 'Ke toan');
insert into bophan values('NS', 'Nhan su');
insert into bophan values('KTh', 'Ky thuat');
insert into bophan values('MKT', 'Marketing');
insert into bophan values('QL', 'Quan ly');
select * from bophan
-- B?ng Ch?c v?
insert into chucvu values('GD', 'Giam doc');
insert into chucvu values('TP', 'Truong phong');
insert into chucvu values('TT', 'To truong');
insert into chucvu values('NV', 'Nhan vien');
insert into chucvu values('PGD', 'Pho giam doc');
select * from chucvu
-- B?ng Tr?nh �?
insert into trinhdo values('CN', 'Cu nhan');
insert into trinhdo values('KS', 'Ky su');
insert into trinhdo values('Ths', 'Thac si');
insert into trinhdo values('TS', 'Tien si');
insert into trinhdo values('CD', 'Cao dang');
insert into trinhdo values('TC', 'Trung cap');
-- B?ng Nh�n vi�n
insert into nhanvien values (1, 'LT', 'NV', 'TC','Nguyen Van A', 'Nam', TO_DATE('1990-01-01', 'YYYY-MM-DD'), '0123456789', '123456789', 'Hai Phong');
insert into nhanvien values (2, 'KT', 'TP', 'Ths','Tran Thi B', 'Nu', TO_DATE('1992-03-15', 'YYYY-MM-DD'),'0987654321', '987654321', 'Ha Noi');
insert into nhanvien values (3, 'NS', 'TT', 'CN','Hoang Van C', 'Nam', TO_DATE('1985-07-20', 'YYYY-MM-DD'),'0369874123', '456123789', 'Ninh Binh');
insert into nhanvien values (4, 'KTh', 'GD', 'TS', 'Le Van D', 'Nam', TO_DATE('1988-05-10', 'YYYY-MM-DD'),'0123456788', '234567890', 'Thai Binh');
insert into nhanvien values (5, 'MKT', 'PGD', 'Ths','Pham Thi E', 'Nu', TO_DATE('1995-12-25', 'YYYY-MM-DD'),'0987654421', '345678901', 'Hung Yen');
insert into nhanvien values (6, 'QL', 'TP', 'CD','Nguyen Van F', 'Nam', TO_DATE('1993-09-18', 'YYYY-MM-DD'), '0369874423', '678901234', 'EcoPark');
insert into nhanvien values (7, 'NS', 'GD', 'CN', 'BuiHong Ha', 'Nu', TO_DATE('1989-07-25', 'YYYY-MM-DD'),'0352874123', '456123719', 'Bac Ninh');
insert into nhanvien values (8, 'KT', 'PGD', 'TS','Pham Thi Thu C', 'Nu', TO_DATE('1983-09-03', 'YYYY-MM-DD'), '0369847123', '465123789', 'Thai Binh');
insert into nhanvien values (9, 'KTh', 'NV', 'KS', 'Do Minh Q', 'Nam', TO_DATE('1998-02-22', 'YYYY-MM-DD'),'0369784123', '456127389', 'Nghe An');
insert into nhanvien values (10, 'QL', 'NV', 'CN','Tran Thi M', 'Nu', TO_DATE('1999-05-26', 'YYYY-MM-DD'),'0384874123', '456321789', 'Hai Duong');
insert into nhanvien values (11, 'KTh', 'TP', 'KS','Trinh Thanh P', 'Nam', TO_DATE('1994-05-26', 'YYYY-MM-DD'), '0384871423', '456321879', 'Hai phong');
insert into nhanvien values (12, 'KT', 'NV', 'CN','Dao Thi THu Ph', 'N?', TO_DATE('1999-01-06', 'YYYY-MM-DD'), '0834874123', '465321789', 'Nam Dinh');
insert into nhanvien values (13, 'MKT', 'TP', 'CN','Nguyen Van N', 'Nam', TO_DATE('1998-10-15', 'YYYY-MM-DD'), '0384784123', '436521789', 'Ha Noi');
insert into nhanvien values (14, 'NS', 'PGD', 'TS','Nguyen Hai H', 'Nam', TO_DATE('1999-03-26', 'YYYY-MM-DD'), '0384872143', '456328179', 'Hung Yen');
insert into nhanvien values (15, 'NS', 'NV', 'CD', 'Vu Hong N', 'Nu', TO_DATE('1998-07-20', 'YYYY-MM-DD'),'0438874123', '456372189', 'Bac Ninh');
select * from nhanvien
-- B?ng Lo?i h?p �?ng
insert into loaihopdong values('01', 'Hop dong lao dong');
insert into loaihopdong values('02', 'Hop dong thu viec');
insert into loaihopdong values('03', 'Hop dong cung ung');
insert into loaihopdong values('04', 'Hop dong chinh thuc');
insert into loaihopdong values('05', 'Hop dong thoi vu');
select * from loaihopdong
-- B?ng H?p �?ng
insert into hopdong values('H1', '01', 1, TO_DATE('2023-01-01', 'YYYY-MM-DD'), TO_DATE('2023-12-31','YYYY-MM-DD'),'12 thang', 1, TO_DATE('2023-01-01', 'YYYY-MM-DD'), 5000.00, 'H?p �?ng lao �?ng');
insert into hopdong values('H2', '02', 2, TO_DATE('2023-02-15', 'YYYY-MM-DD'), TO_DATE('2023-08-15','YYYY-MM-DD'), '6 thang', 1, TO_DATE('2023-02-15', 'YYYY-MM-DD'), 8000.00, 'H?p �?ng thu viec');
insert into hopdong values('H3', '03', 3, TO_DATE('2022-03-20', 'YYYY-MM-DD'), TO_DATE('2023-09-20','YYYY-MM-DD'), '18 thang', 2, TO_DATE('2023-03-20', 'YYYY-MM-DD'), 6000.00, 'H?p �?ng ch�nh th?c');
insert into hopdong values('H4', '05', 4, TO_DATE('2023-04-05', 'YYYY-MM-DD'), TO_DATE('2023-10-05','YYYY-MM-DD'), '6 thang', 3, TO_DATE('2023-04-05', 'YYYY-MM-DD'), 7000.00, 'Hop dong thu viec');
insert into hopdong values('H5', '04', 5, TO_DATE('2023-05-10', 'YYYY-MM-DD'), TO_DATE('2023-11-10','YYYY-MM-DD'), '6 thang', 5, TO_DATE('2023-05-10', 'YYYY-MM-DD'), 9000.00, 'Hop dong thoi vu');
insert into hopdong values('H6', '04', 6, TO_DATE('2023-12-10', 'YYYY-MM-DD'), TO_DATE('2024-3-10','YYYY-MM-DD'), '3 thang', 4, TO_DATE('2023-05-10', 'YYYY-MM-DD'), 5500.00, 'Hop dong thoi vu');
insert into hopdong values('H7', '02', 7, TO_DATE('2023-06-10', 'YYYY-MM-DD'), TO_DATE('2023-12-10','YYYY-MM-DD'), '6 thang', 1, TO_DATE('2023-05-10', 'YYYY-MM-DD'), 9000.00, 'Hop dong thu viec');
insert into hopdong values('H8', '01', 8, TO_DATE('2021-05-10', 'YYYY-MM-DD'), TO_DATE('2025-05-10','YYYY-MM-DD'), '48 thang',1 , TO_DATE('2021-05-10', 'YYYY-MM-DD'), 10000.00, 'Hop dong chinh thuc');
insert into hopdong values('H9', '04', 9, TO_DATE('2022-05-22', 'YYYY-MM-DD'), TO_DATE('2024-5-22','YYYY-MM-DD'), '24 thang', 2, TO_DATE('2023-05-10', 'YYYY-MM-DD'), 6500.00, 'Hop dong chinh thuc');
insert into hopdong values('H10', '04',10, TO_DATE('2023-06-30', 'YYYY-MM-DD'), TO_DATE('2023-12-30','YYYY-MM-DD'), '6 thang', 1, TO_DATE('2023-05-10', 'YYYY-MM-DD'), 4000.00, 'Hop dong thu viec');
insert into hopdong values('H11', '01',11, TO_DATE('2023-07-30', 'YYYY-MM-DD'), TO_DATE('2024-7-30','YYYY-MM-DD'), '12 thang', 1, TO_DATE('2023-07-20', 'YYYY-MM-DD'), 5000.00, 'Hop dong lao �?ng');
insert into hopdong values('H12', '01',12, TO_DATE('2023-08-30', 'YYYY-MM-DD'), TO_DATE('2024-08-30','YYYY-MM-DD'), '12 thang', 1, TO_DATE('2023-08-10', 'YYYY-MM-DD'), 4000.00, 'Hop dong lao �?ng');
insert into hopdong values('H13', '01',13, TO_DATE('2023-09-30', 'YYYY-MM-DD'), TO_DATE('2024-09-30','YYYY-MM-DD'), '12 thang', 1, TO_DATE('2023-09-10', 'YYYY-MM-DD'), 4000.00, 'Hop dong lao �?ng');
insert into hopdong values('H14', '01',14, TO_DATE('2023-10-30', 'YYYY-MM-DD'), TO_DATE('2024-10-30','YYYY-MM-DD'), '12 thang', 1, TO_DATE('2023-10-10', 'YYYY-MM-DD'), 4000.00, 'Hop dong lao �?ng');
insert into hopdong values('H15', '01',15, TO_DATE('2023-11-30', 'YYYY-MM-DD'), TO_DATE('2024-11-30','YYYY-MM-DD'), '12 thang', 1, TO_DATE('2023-11-10', 'YYYY-MM-DD'), 4000.00, 'Hop dong lao �?ng');
select *from hopdong
-- B?ng B?o hi?m
insert into baohiem values('B1', 1, 'BH123456',TO_DATE('2023-01-15', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� A');
insert into baohiem values('B2',2, 'BH789012', TO_DATE('2023-02-20', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� B');
insert into baohiem values('B3', 3, 'BH543210', TO_DATE('2023-05-10', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� C');
insert into baohiem values('B4', 4, 'BH987654', TO_DATE('2023-06-01', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� D');
insert into baohiem values('B5', 5, 'BH456789', TO_DATE('2023-07-15', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� E');
insert into baohiem values('B6', 6, 'BH345678', TO_DATE('2023-07-21', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n B?ch Mai', 'Chi nh�nh ��ngk� A');
insert into baohiem values('B7', 7, 'BH456789', TO_DATE('2023-07-22', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n B?ch Mai', 'Chi nh�nh ��ng k� B');
insert into baohiem values('B8', 8, 'BH876543', TO_DATE('2023-08-22', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n B?ch Mai', 'Chi nh�nh ��ng k� C');
insert into baohiem values('B9', 9, 'BH765432', TO_DATE('2023-09-22', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n B?ch Mai', 'Chi nh�nh ��ng k� D');
insert into baohiem values('B10', 10, 'BH654321', TO_DATE('2023-10-22', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n B?ch Mai', 'Chi nh�nh ��ng k� E');
insert into baohiem values('B11', 11, 'BH543211', TO_DATE('2023-05-11', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� C');
insert into baohiem values('B12', 12, 'BH543212', TO_DATE('2023-05-12', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� D');
insert into baohiem values('B13', 13, 'BH543213', TO_DATE('2023-05-13', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� E');
insert into baohiem values('B14', 14, 'BH543214', TO_DATE('2023-05-14', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� F');
insert into baohiem values('B15', 15, 'BH543215', TO_DATE('2023-05-15', 'YYYY-MM-DD'), 'C� quan B?o hi?m X? h?i', 'B?nh vi?n Vi?t �?c', 'Chi nh�nh ��ng k� C');
select *from baohiem
-- B?ng Khen th�?ng
insert into khenthuong values('K1', 1, 'QD001',TO_DATE('2023-01-20', 'YYYY-MM-DD'), N'Th�?ng th�nh t�ch xu?t s?c', 500.00);
insert into khenthuong values ('K2', 5, 'QD002',TO_DATE('2023-02-25', 'YYYY-MM-DD'), N'�?t m?c ti�u kinh doanh', 800.00);
insert into khenthuong values ('K3', 8, 'QD003',TO_DATE('2023-03-10', 'YYYY-MM-DD'), N'��ng g�p t�ch c?c v�o d? �n', 1000.00);
insert into khenthuong values ('K4', 1, 'QD004',TO_DATE('2023-04-10', 'YYYY-MM-DD'), N'��ng g�p t�ch c?c v�o d? �n', 1000.00);

select * from khenthuong
-- B?ng K? lu?t
insert into kyluat values('KL1', 3, 'QDKL001',TO_DATE('2023-04-05', 'YYYY-MM-DD'), N'Vi ph?m quy t?c c�ng ty', 100.00);
insert into kyluat values('KL2', 6, 'QDKL002',TO_DATE('2023-05-10', 'YYYY-MM-DD'), N'Vi ph?m quy �?nh an to�n lao �?ng', 200.00);
insert into kyluat values('KL3', 7, 'QDKL003',TO_DATE('2023-06-15', 'YYYY-MM-DD'), N'Vi ph?m quy �?nh v? th?i gian l�m vi?c', 150.00);
select *from kyluat
-- B?ng Lo?i ca
insert into loaica values('L1', 'Ca S�ng', 1.2);
insert into loaica values('L2', 'Ca Chi?u', 1.5);
insert into loaica values('L3', 'Ca T?i', 1.3);
insert into loaica values('L4', 'Ch? nh?t', 1.5);
insert into loaica values('L5', 'Ng�y l?', 2);
select *from loaica
-- B?ng T�ng ca
insert into tangca values('TC1', 3, 'L1',TO_DATE('2023-01-10', 'YYYY-MM-DD'), 2.5);
insert into tangca values('TC2', 5, 'L2',TO_DATE('2023-02-15', 'YYYY-MM-DD'), 3.0);
insert into tangca values('TC3', 7, 'L3',TO_DATE('2023-03-20', 'YYYY-MM-DD'), 2.0);
insert into tangca values('TC4', 8, 'L4',TO_DATE('2023-04-05', 'YYYY-MM-DD'), 5.0);
insert into tangca values('TC5', 2, 'L5',TO_DATE('2023-05-10', 'YYYY-MM-DD'), 3.5);
insert into tangca values('TC6', 4, 'L4',TO_DATE('2023-06-15', 'YYYY-MM-DD'), 4);
select * from tangca
-- B?ng Lo?i c�ng
insert into loaicong values('LC1', 'C�ng b?nh th�?ng',1.0);
insert into loaicong values('LC2', 'C�ng t�ng ca ng�y th�?ng', 1.5);
insert into loaicong values('LC3', 'C�ng t�ng ca ng�y ngh?', 2.0);
insert into loaicong values('LC4', 'C�ng t�ng ca ng�y l?', 3.0);
select*from loaicong
-- B?ng Thai s?n
insert into thaisan values(2, 'Tran Thi B',TO_DATE('2023-01-05', 'YYYY-MM-DD'), TO_DATE('2023-07-09','YYYY-MM-DD'), 20000.00);
insert into thaisan values(5, 'Pham Thi E',TO_DATE('2023-03-10', 'YYYY-MM-DD'), TO_DATE('2023-09-20','YYYY-MM-DD'), 25000.00);
insert into thaisan values(10, 'Tran Thi M',TO_DATE('2023-08-15', 'YYYY-MM-DD'), TO_DATE('2024-02-25','YYYY-MM-DD'),15000.00);
select *from thaisan
-- B?ng Ph? c?p
insert into phucap values('PC1', 'Ph? c?p 1', 2000.0);
insert into phucap values('PC2', 'Ph? c?p 2', 2500.0);
insert into phucap values('PC3', 'Ph? c?p 3', 2800.0);
select * from phucap
-- B?ng Ph? c?p nh�n vi�n
insert into nv_phu_cap values('1','PC3','Ph? c?p 3');
insert into nv_phu_cap values('2','PC2','Ph? c?p 2');
insert into nv_phu_cap values('3','PC1', 'Ph? c?p 1');
insert into nv_phu_cap values('4','PC1', 'Ph? c?p 1');
insert into nv_phu_cap values('5','PC2', 'Ph? c?p 2');
insert into nv_phu_cap values('6','PC3', 'Ph? c?p 3');
insert into nv_phu_cap values('7','PC3', 'Ph? c?p 3');
insert into nv_phu_cap values('8','PC2','Ph? c?p 2');
insert into nv_phu_cap values('9','PC1','Ph? c?p 1');
insert into nv_phu_cap values('10','PC2', 'Ph? c?p 2');
select * from nv_phu_cap
-- B?ng �i?u chuy?n
insert into dieuchuyen values('DC1',4,'KTh','QL','Chuy?n �?n b? ph?n m?i');
insert into dieuchuyen values('DC2',5,'MKT','NS','Chuy?n �?n b? ph?n m?i');
insert into dieuchuyen values('DC3',6,'QL','LT','Chuy?n �?n b? ph?n m?i');
insert into dieuchuyen values('DC4',7,'NS','MKT','Chuy?n �?n b? ph?n m?i');
select * from dieuchuyen
--B?ng Th�i vi?c
insert into thoiviec values('TV1',11,TO_DATE('2023-09-15', 'YYYY-MM-DD'),'Ngh? vi?c t? nguy?n');
insert into thoiviec values('TV2',12,TO_DATE('2023-10-16', 'YYYY-MM-DD'),'Ch?m d?t h?p �?ng lao �?ng');
insert into thoiviec values('TV3',13,TO_DATE('2023-11-17', 'YYYY-MM-DD'),'Ch?m d?t h?p �?ng lao �?ng v? l? do c� nh�n');
-- B?ng T�ng l��ng
insert into tangluong values('TL1',5,'MKT','PGD',TO_DATE('2023-08-10', 'YYYY-MM-DD'),'T�ng l��ng th�?ng ni�n',2000.00 );
insert into tangluong values('TL2',7,'NS','GD',TO_DATE('2023-09-14', 'YYYY-MM-DD'), 'T�ng l��ng th�?ng ni�n', 4000.00);
insert into tangluong values('TL3',9,'KTh','NV',TO_DATE('2023-10-19', 'YYYY-MM-DD'), 'T�ng l��ng �?t xu?t', 1500.00);
insert into tangluong values('TL4',14,'NS','PGD',TO_DATE('2023-11-10', 'YYYY-MM-DD'), 'T�ng l��ng th�?ng ni�n', 2000.00);
insert into tangluong values('TL5',15,'NS','NV',TO_DATE('2023-12-25', 'YYYY-MM-DD'), 'T�ng l��ng theo quy �?nh', 500.00);
-- B?ng K? ch?m c�ng
insert into kychamcong values('KCC1',1,2023,TO_DATE('2023-01-10', 'YYYY-MM-DD'));
insert into kychamcong values('KCC2',2,2023,TO_DATE('2023-02-10', 'YYYY-MM-DD'));
insert into kychamcong values('KCC3',3,2023,TO_DATE('2023-03-10', 'YYYY-MM-DD'));
insert into kychamcong values('KCC4',4,2023,TO_DATE('2023-04-10', 'YYYY-MM-DD'));
insert into kychamcong values('KCC5',5,2023,TO_DATE('2023-05-10', 'YYYY-MM-DD'));
insert into kychamcong values('KCC6',6,2023,TO_DATE('2023-06-10', 'YYYY-MM-DD'));
-- B?ng Chi ti?t K? ch?m c�ng
insert into CT_KCC values('KCC2',1,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',2,1, 1, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 25);
insert into CT_KCC values('KCC2',3,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1,0, 1, 0, 1, 0, 1, 25);
insert into CT_KCC values('KCC2',4,1, 1, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 26);
insert into CT_KCC values('KCC2',5,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',6,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1,0, 1, 0, 1, 0, 1, 23);
insert into CT_KCC values('KCC2',7,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1,0, 1, 0, 1, 0, 1, 22);
insert into CT_KCC values('KCC2',8,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',9,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',10,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 0, 0, 1, 23);
insert into CT_KCC values('KCC2',11,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,1, 1, 0, 1, 0, 1, 25);
insert into CT_KCC values('KCC2',12,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',13,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',14,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
insert into CT_KCC values('KCC2',15,1, 0, 1, 1, 1, 1,1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1,0, 1, 0, 1, 0, 1, 24);
select * from CT_KCC
-- B?ng B?ng c�ng
insert into bangcong values('BC1','LC1',1,TO_TIMESTAMP('2023-01-01 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC2','LC2',2,TO_TIMESTAMP('2023-01-03 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 18:00:00', 'YYYY-MM-DD HH24:MI:SS'), 10);
insert into bangcong values('BC3','LC3',3,TO_TIMESTAMP('2023-01-04 09:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 8);
insert into bangcong values('BC4','LC1',4,TO_TIMESTAMP('2023-01-01 09:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 18:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC5','LC2',5,TO_TIMESTAMP('2023-01-01 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC6','LC3',6,TO_TIMESTAMP('2023-01-11 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC7','LC1',7,TO_TIMESTAMP('2023-01-01 07:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 10);
insert into bangcong values('BC8','LC2',8,TO_TIMESTAMP('2023-01-01 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC9','LC3',9,TO_TIMESTAMP('2023-01-21 08:00:00','YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC10','LC1',10,TO_TIMESTAMP('2023-01-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 8);
insert into bangcong values('BC11','LC2',11,TO_TIMESTAMP('2023-01-31 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC12','LC3',12,TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC13','LC1',13,TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC14','LC2',14,TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
insert into bangcong values('BC15','LC3',15,TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
select * from bangcong
-- B?ng Chi ti?t b?ng c�ng
insert into ChiTietBangCong values('BC1','KCC2',1,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,1,2);
insert into ChiTietBangCong values('BC2','KCC2',2,TO_DATE('2023-01-03', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-03 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 18:00:00', 'YYYY-MM-DD HH24:MI:SS'),5,1,3);
insert into ChiTietBangCong values('BC3','KCC2',3,TO_DATE('2023-01-04', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-04 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),5,0,2);
insert into ChiTietBangCong values('BC4','KCC2',4,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 18:00:00', 'YYYY-MM-DD HH24:MI:SS'),4,1,4);
insert into ChiTietBangCong values('BC5','KCC2',5,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,0,3);
insert into ChiTietBangCong values('BC6','KCC2',6,TO_DATE('2023-01-11', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-11 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),7,0,0);
insert into ChiTietBangCong values('BC7','KCC2',7,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 07:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),8,0,0);
insert into ChiTietBangCong values('BC8','KCC2',8,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,1,2);
insert into ChiTietBangCong values('BC9','KCC2',9,TO_DATE('2023-01-21', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,0,2);
insert into ChiTietBangCong values('BC10','KCC2',10,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),7,0,2);
insert into ChiTietBangCong values('BC11','KCC2',11,TO_DATE('2023-01-31', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-31 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-31 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),5,1,2);
insert into ChiTietBangCong values('BC12','KCC2',12,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,0,2);
insert into ChiTietBangCong values('BC13','KCC2',13,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,0,0);
insert into ChiTietBangCong values('BC14','KCC2',14,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,1,0);
insert into ChiTietBangCong values('BC15','KCC2',15,TO_DATE('2023-01-01', 'YYYY-MM-DD'),TO_TIMESTAMP('2023-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 17:00:00', 'YYYY-MM-DD HH24:MI:SS'),6,0,1);
select * from ChiTietBangCong
-- B?ng L��ng
insert into Luong values('BL1','KCC2','1','Nguyen Van A',24,6,1,1,2);
insert into Luong values('BL2','KCC2','2','Tran Thi B',25,5,1,1,3);
insert into Luong values('BL3','KCC2','3','Hoang Van C',25,5,1,0,2);
insert into Luong values('BL4','KCC2','4','Le Van D',26,4,0,1,4);
insert into Luong values('BL5','KCC2','5','Pham Thi E',24,6,1,0,3);
insert into Luong values('BL6','KCC2','6','Nguyen Van F',23,7,2,0,0);
insert into Luong values('BL7','KCC2','7','Bui Hong Ha',22,8,3,0,0);
insert into Luong values('BL8','KCC2','8','Pham Thi Thu C',24,6,1,1,2);
insert into Luong values('BL9','KCC2','9','Do Minh Q',24,6,1,0,2);
insert into Luong values('BL10','KCC2','10','Tran Thi M',23,7,1,1,2);
insert into Luong values('BL11','KCC2','11','Trinh Thanh P',25,5,1,1,2);
insert into Luong values('BL12','KCC2','12','Dao Thi Thu Ph',24,6,0,0,2);
insert into Luong values('BL13','KCC2','13','Nguyen Van N',24,6,0,0,0);
insert into Luong values('BL14','KCC2','14','Nguyen Hai H',24,6,1,1,0);
insert into Luong values('BL15','KCC2','15','Vu Hong N',24,6,0,0,1);
-- B?ng Th? vi?c
insert into ThuViec values('TV2',2,'Tran Thi B','KT');
insert into ThuViec values('TV7',7,'Bui Hong Ha','NS');
insert into ThuViec values('TV10',10,'Tran Thi M','QL');

--CAU LENH TRUY VAN
--Cau 1: Cho bi?t ng�y sinh v� s? �i?n tho?i c?a nh�n vi�n t�n �Nguyen Van A�
SELECT hoten, ngaysinh, dienthoai
FROM nhanvien
WHERE hoten = N'Nguyen Van A';
--Cau 2: In ra danh s�ch th�ng tin nh�n vi�n s? h?t h?n h?p �?ng trong th�ng 11
SELECT nhanvien.maNV, hoten, Ngayketthuc, TenBP, tencv
FROM nhanvien JOIN bophan ON nhanvien.mabp = bophan.mabp
JOIN chucvu ON nhanvien.macv = chucvu.macv
JOIN hopdong ON nhanvien.manv = hopdong.manv
WHERE EXTRACT (MONTH FROM ngayketthuc) = 11;
--Cau 3: Tra c?u b? ph?n c� s? ng�?i b? k? lu?t nhi?u nh?t
SELECT tenbp, COUNT(kyluat.manv) AS soluong
FROM nhanvien JOIN bophan ON nhanvien.mabp = bophan.mabp
JOIN kyluat ON nhanvien.manv = kyluat.manv
GROUP BY bophan.tenbp
ORDER BY COUNT(kyluat.manv) desc
FETCH FIRST ROW ONLY
--Cau 4: In ra Top 3 Nh�n vi�n c� s? ti?n t�ng l��ng nhi?u nh?t
SELECT nhanvien.manv, hoten, sotien
FROM nhanvien JOIN tangluong ON nhanvien.manv = tangluong.manv
ORDER BY sotien DESC
FETCH FIRST 3 ROWs ONLY;
--Cau 5: In ra  s? nh�n vi�n ngh? kh�ng qu� 5 l?n
SELECT COUNT(ngayphep) AS SoNhanVienNghiKhongQua5Lan
FROM chitietbangcong
WHERE ngayphep <=5;
--Cau 6: In ra danh s�ch nh�n vi�n b? tr? l��ng
SELECT NV.MaNV, NV.Hoten, KL.SoTien
FROM Nhanvien NV
JOIN Kyluat KL ON KL.manv = NV.manv;
--Cau 7: Truy v?n nh?ng nh�n vi�n ��?c khen th�?ng nhi?u l?n
SELECT nhanvien.manv, hoten, COUNT(nhanvien.manv) AS solanduockhenthuong
FROM nhanvien JOIN khenthuong ON nhanvien.manv = khenthuong.manv
HAVING COUNT(nhanvien.manv) >1
GROUP BY nhanvien.manv, nhanvien.hoten;
--Cau 8: T�nh t?ng s? ti?n khen th�?ng c�c nh�n vi�n th�ng 1
select sum(sotien) as tongtienthuongthang1
from khenthuong
where extract(month from ngay) =1;
--Cau 9: Hi?n th? danh s�ch nh�n vi�n theo b? ph?n v� s? l�?ng nh�n vi�n trong m?i b? ph?n
SELECT bophan.tenbp AS TenBoPhan, COUNT(Nhanvien.manv) AS soluongnhanvien
FROM bophan
LEFT JOIN nhanvien ON bophan.mabp = nhanvien.mabp
GROUP BY bophan.tenbp;
--Cau 10:  L?y danh s�ch nh�n vi�n c� sinh nh?t trong th�ng n�y v� s?p x?p theo ng�y sinh
SELECT manv, hoten, ngaysinh
FROM nhanvien
WHERE EXTRACT(MONTH FROM ngaysinh) = EXTRACT (MONTH FROM sysdate)
ORDER BY ngaysinh;
--Cau 11: T�nh t?ng s? ng�y ngh? ph�p �? s? d?ng c?a m?i nh�n vi�n trong n�m nay
SELECT nv.manv,nv.hoten,l.ngayphep AS tongngaynghi
FROM luong L JOIN NhanVien NV
On L.MaNv = NV.maNV
--Cau 12: Hi?n th? danh s�ch nh?ng nh�n vi�n c� tu?i d�?i 30 v� s?p x?p theo tu?i t�ng d?n.
Select manv,hoten,(extract(year from sysdate) - extract(year from ngaysinh)) as tuoi
FROM nhanvien
WHERE (extract (year from sysdate) - extract (year from ngaysinh)) < 30
ORDER BY tuoi asc;
-- Cau 13: Hi?n th? danh s�ch nh?ng nh�n vi�n �? nh?n th�?ng ho?c khen ng?i trong n�m nay v� ng�y nh?n th�?ng.
SELECT NV.MaNV, NV.Hoten, COALESCE(KT.Ngay, K.Ngay) AS NgayNhanThuong
FROM Nhanvien NV
LEFT JOIN Khenthuong KT ON NV.MaNV = KT.MaNV
LEFT JOIN KhenThuong K ON NV.MaNV = K.MaNV
WHERE (EXTRACT(YEAR FROM COALESCE(KT.Ngay, K.Ngay)) = EXTRACT (YEAR FROM SYSDATE));

--3.1 PL/SQL
set serveroutput on
-- ��a ra t?ng s? nh�n vi�n t?i c?a h�ng
DECLARE
 totalEmployees NUMBER;
BEGIN
 SELECT COUNT(*) INTO totalEmployees FROM NhanVien;
 DBMS_OUTPUT.PUT_LINE('Tong so nhan vien trong cua hang: ' || 
totalEmployees);
END;
-- L?y danh s�ch c�c nh�n vi�n trong m?t b? ph?n c? th?
DECLARE
 department_id bophan.MaBP%TYPE := 'KT';
BEGIN
 FOR employee_rec IN (SELECT * FROM NhanVien WHERE MaBP = 
department_id) LOOP
 DBMS_OUTPUT.PUT_LINE('Ma nhan vien: ' || employee_rec.MaNV || 
', Ho va ten: ' || employee_rec.HoTen);
 END LOOP;
END;
-- T�nh t?ng l��ng c?a t?t c? nh�n vi�n trong c?a h�ng
DECLARE
 total_salary NUMBER;
BEGIN
 SELECT SUM(LuongCoBan) INTO total_salary FROM hopdong;
 DBMS_OUTPUT.PUT_LINE('Tong luong cua tat ca nhan vien: ' || 
total_salary);
END;
-- Hi?n th? th�ng tin h?p �?ng c?a nh�n vi�n d?a tr�n m? nh�n vi�n
DECLARE
 employee_id NhanVien.MaNV%TYPE := '1';
BEGIN
 FOR contract_rec IN (SELECT * FROM hopdong WHERE MaNV = 
employee_id) LOOP
 DBMS_OUTPUT.PUT_LINE('Ma hop dong: ' || contract_rec.MaHD || 
', Ng�y ki: ' || contract_rec.NgayKy);
 END LOOP;
END;
-- Ki?m tra xem m?t nh�n vi�n c� �?t tr?nh �? n�o �� kh�ng
DECLARE
 employee_id NhanVien.MaNV%TYPE := '3';
 education_level trinhdo.MaTD%TYPE := 'Ths';
 has_education_level NUMBER;
BEGIN
 SELECT COUNT(*) INTO has_education_level 
 FROM NhanVien 
 WHERE MaNV = employee_id 
 AND MaTD = education_level;
 IF has_education_level > 0 THEN
 DBMS_OUTPUT.PUT_LINE('Nhan vien c� ma ' || employee_id || ' 
dat trinh do ' || education_level);
 ELSE
 DBMS_OUTPUT.PUT_LINE('Nhan vien co ma ' || employee_id || ' 
KHONG dat trinh do ' || education_level);
 END IF;
END;


--HAM
-- T�nh t?ng l��ng c?a t?t c? nh�n vi�n trong c?a h�ng
CREATE OR REPLACE FUNCTION TinhTongLuong RETURN NUMBER IS
 tong_luong NUMBER;
BEGIN
 SELECT SUM(LuongCoBan) INTO tong_luong FROM hopdong;
 RETURN tong_luong;
END;
DECLARE
    v_tong_luong NUMBER;
BEGIN
    v_tong_luong := TinhTongLuong();
    DBMS_OUTPUT.PUT_LINE('Tong luong la: ' || v_tong_luong);
END;
-- Ki?m tra xem m?t nh�n vi�n c� �?t tr?nh �? h?c v? n�o �� kh�ng
CREATE OR REPLACE FUNCTION KiemTraTrinhDo(p_MaNV NhanVien.MaNV%TYPE,
p_MaTD TrinhDo.MaTD%TYPE) RETURN VARCHAR2 IS
 result VARCHAR2(100);
BEGIN
 SELECT CASE WHEN COUNT(*) > 0 THEN 'Nh�n vi�n c� m? ' || p_MaNV || 
' �at trinh �o ' || p_MaTD 
 ELSE 'Nh�n vi�n c� ma ' || p_MaNV || ' KH�NG �at trinh 
�? ' || p_MaTD
 END
 INTO result
 FROM NhanVien
 WHERE MaNV = p_MaNV AND MaTD = p_MaTD;
 RETURN result;
END;
DECLARE
    v_result VARCHAR2(100);
BEGIN
    v_result := KiemTraTrinhDo('1', 'CN');
    DBMS_OUTPUT.PUT_LINE(v_result);
END;
-- T�nh tu?i c?a m?t nh�n vi�n d?a tr�n ng�y sinh
CREATE OR REPLACE FUNCTION TinhTuoi(p_MaNV NhanVien.MaNV%TYPE) RETURN 
NUMBER IS
 tuoi NUMBER;
BEGIN
 SELECT FLOOR(MONTHS_BETWEEN(SYSDATE, NgaySinh) / 12) INTO tuoi 
FROM NhanVien WHERE MaNV = p_MaNV;
 RETURN tuoi;
END;
DECLARE
    v_tuoi NUMBER;
BEGIN
    -- G?i h�m �? t�nh tu?i c?a nh�n vi�n c� m? '5'
    v_tuoi := TinhTuoi('5');
    DBMS_OUTPUT.PUT_LINE('Tuoi cua nhan vien 5 la: ' || v_tuoi);
END;
--TH? T?C
-- C?p nh?t th�ng tin nh�n vi�n
CREATE OR REPLACE PROCEDURE CapNhatThongTinNV (p_MaNV CHAR, p_HoTen 
NVARCHAR2, p_DiaChi NVARCHAR2) IS
BEGIN
 UPDATE NhanVien SET HoTen = p_HoTen, DiaChi = p_DiaChi WHERE MaNV 
= p_MaNV;
 COMMIT;
 DBMS_OUTPUT.PUT_LINE('�? c?p nh?t th�ng tin nh�n vi�n th�nh 
c�ng!');
END;
DECLARE
    v_MaNV CHAR(10) := '1';  
    v_HoTen NVARCHAR2(100) := 'Hoang Phuong T';  
    v_DiaChi NVARCHAR2(200) := 'Smart City'; 
BEGIN
    CapNhatThongTinNV(v_MaNV, v_HoTen, v_DiaChi);
END;

SELECT name, open_mode FROM v$database;
ALTER DATABASE OPEN;

select * from nhanvien;
